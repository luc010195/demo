<?php

defined('_JEXEC') or die;

/**
 * This file belongs to mPDF Joomla! library which was packaged by CMExtension.
 * mPDF is PHP library for generating PDF.
 * CMExtension only created this package for installing into Joomla! CMS.
 * All credits for mPDF belong to Ian Back and the contributors.
 */

$collation = array (
  1456 => 173,
  1457 => 173,
  1458 => 173,
  1459 => 173,
  1460 => 173,
  1461 => 173,
  1462 => 173,
  1463 => 173,
  1464 => 173,
  1465 => 173,
  1466 => 173,
  1467 => 173,
  1468 => 173,
  1469 => 173,
  1471 => 173,
  1472 => 173,
  1473 => 173,
  1474 => 173,
  710 => 94,
  189 => 188,
  190 => 179,
  65 => 97,
  66 => 98,
  67 => 99,
  68 => 100,
  69 => 101,
  70 => 102,
  402 => 102,
  71 => 103,
  72 => 104,
  73 => 105,
  74 => 106,
  75 => 107,
  76 => 108,
  77 => 109,
  78 => 110,
  79 => 111,
  80 => 112,
  81 => 113,
  82 => 114,
  83 => 115,
  84 => 116,
  85 => 117,
  86 => 118,
  87 => 119,
  88 => 120,
  89 => 121,
  90 => 122,
  1520 => 1493,
  1521 => 1493,
  1522 => 1497,
  1499 => 1498,
  1502 => 1501,
  1504 => 1503,
  1508 => 1507,
  1510 => 1509,
);
?>